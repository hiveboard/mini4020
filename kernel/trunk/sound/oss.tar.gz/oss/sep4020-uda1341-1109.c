/*
2008-11-07 begin to write sep4020-uda1341.c according to s3c2410-uda1341.c
if I find somewhere uncertain,I will use //uncertain! aokikyon
if I find somewhere to modify,I will use //modified by kyon
if I killed something, I will use //killed by kyon
2008-11-08 sep4020 使用PWM提供UDA1341的SYSCLK信号 不需要获取芯片主频，删除掉和系统时钟相关的代码
但是PWM依然和CPU时钟相关，目前sep4020主频固定在88MHz PWM采8分频 PWM输出为11MHz 在256fs下 采样率11MHz／256＝42.96k 暂时这么设定
2008-11-09 修改初始化iis函数 修改初始化dma函数 设置iis的采样率固定为44.1kHz
*/
#define DEBUG

#include <linux/module.h>
#include <linux/device.h>
#include <linux/init.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/sched.h>
#include <linux/poll.h>
#include <linux/interrupt.h>
#include <linux/errno.h>
#include <linux/sound.h>
#include <linux/soundcard.h>
#include <linux/pm.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <asm/hardware.h>
#include <asm/semaphore.h>
#include <asm/dma.h>
#include <asm/arch/dma.h>
//#include <asm/arch/regs-gpio.h>	//killed by kyon
//#include <asm/arch/regs-iis.h>	//killed by kyon
//#include <asm/hardware/clock.h>	//killed by kyon
//#include <asm/arch/regs-clock.h>	//killed by kyon
#include <linux/dma-mapping.h>
#include <asm/dma-mapping.h>
#include <asm/arch/hardware.h>
//#include <asm/arch/map.h>		//killed by kyon
//#include <asm/arch/S3C2410.h>	//killed by kyon
#include <linux/platform_device.h> 	//added 11-07 by kyon
//#include <asm/arch/bitfield.h> 	//added when I worked this with s3c2410  killed 11-09
#include <asm/arch/irqs.h>		//added 11-08

#define PFX "sep4020-uda1341: "

//************************************************* added 11-09
//     define I2S_T registers
//*************************************************/
#define   HALF_FIFO 4

#define   MUTE(X)       (X << 25)
#define   RESET_1(X)      (X << 24)
#define   ALIGN(X)      (X << 23)
#define   WS(X)         (X << 22)
#define   WID(X)        (X << 20)
#define   DIR(X)        (X << 19)
#define   MODE(X)       (X << 18)
#define   MONO(X)       (X << 17)
#define   STOP(X)       (X << 16)
#define   DIV(X)        X

#define MAX_DMA_CHANNELS 0 

#define MAX_sep4020_DMA_CHANNELS 6	//sep4020 has 6 channel!

#define DMA_CH0 0	//used by sep4020 nand emi
#define DMA_CH1 1
#define DMA_CH2 2
#define DMA_CH3 3
#define DMA_CH4 4
#define DMA_CH5 5

#define DMA_BUF_WR 1
#define DMA_BUF_RD 0

#define dma_wrreg(chan, reg, val) writel((val), (chan)->regs + (reg))  //uncertain wheather it will work well

//static struct clk *iis_clock; //11-08
static void __iomem *iis_base;	
/*
static struct s3c2410_dma_client s3c2410iis_dma_out= {
.name = "I2SSDO",
};
*/
static struct sep4020iis_dma_out;	//this is a problem
/*
static struct s3c2410_dma_client s3c2410iis_dma_in = {
.name = "I2SSDI",
};
*/
static struct sep4020iis_dma_in;	//this is a problem

#ifdef DEBUG
#define DPRINTK printk
#else
#define DPRINTK( x... )
#endif

static void init_sep4020_iis_bus_rx(void);
static void init_sep4020_iis_bus_tx(void);

#define DEF_VOLUME 65

/* UDA1341 Register bits */
#define UDA1341_ADDR 0x14
#define UDA1341_REG_DATA0 (UDA1341_ADDR + 0)
#define UDA1341_REG_STATUS (UDA1341_ADDR + 2)

/* status control */
#define STAT0 (0x00)
#define STAT0_RST (1 << 6)
#define STAT0_SC_MASK (3 << 4)
#define STAT0_SC_512FS (0 << 4)
#define STAT0_SC_384FS (1 << 4)
#define STAT0_SC_256FS (2 << 4)
#define STAT0_IF_MASK (7 << 1)
#define STAT0_IF_I2S (0 << 1)
#define STAT0_IF_LSB16 (1 << 1)
#define STAT0_IF_LSB18 (2 << 1)
#define STAT0_IF_LSB20 (3 << 1)
#define STAT0_IF_MSB (4 << 1)
#define STAT0_IF_LSB16MSB (5 << 1)
#define STAT0_IF_LSB18MSB (6 << 1)
#define STAT0_IF_LSB20MSB (7 << 1)
#define STAT0_DC_FILTER (1 << 0)
#define STAT0_DC_NO_FILTER (0 << 0)

#define STAT1 (0x80)
#define STAT1_DAC_GAIN (1 << 6) /* gain of DAC */
#define STAT1_ADC_GAIN (1 << 5) /* gain of ADC */
#define STAT1_ADC_POL (1 << 4) /* polarity of ADC */
#define STAT1_DAC_POL (1 << 3) /* polarity of DAC */
#define STAT1_DBL_SPD (1 << 2) /* double speed playback */
#define STAT1_ADC_ON (1 << 1) /* ADC powered */
#define STAT1_DAC_ON (1 << 0) /* DAC powered */

/* data0 direct control */
#define DATA0 (0x00)
#define DATA0_VOLUME_MASK (0x3f)
#define DATA0_VOLUME(x) (x)

#define DATA1 (0x40)
#define DATA1_BASS(x) ((x) << 2)
#define DATA1_BASS_MASK (15 << 2)
#define DATA1_TREBLE(x) ((x))
#define DATA1_TREBLE_MASK (3)

#define DATA2 (0x80)
#define DATA2_PEAKAFTER (0x1 << 5)
#define DATA2_DEEMP_NONE (0x0 << 3)
#define DATA2_DEEMP_32KHz (0x1 << 3)
#define DATA2_DEEMP_44KHz (0x2 << 3)
#define DATA2_DEEMP_48KHz (0x3 << 3)
#define DATA2_MUTE (0x1 << 2)
#define DATA2_FILTER_FLAT (0x0 << 0)
#define DATA2_FILTER_MIN (0x1 << 0)
#define DATA2_FILTER_MAX (0x3 << 0)
/* data0 extend control */
#define EXTADDR(n) (0xc0 | (n))
#define EXTDATA(d) (0xe0 | (d))

#define EXT0 0
#define EXT0_CH1_GAIN(x) (x)
#define EXT1 1
#define EXT1_CH2_GAIN(x) (x)
#define EXT2 2
#define EXT2_MIC_GAIN_MASK (7 << 2)
#define EXT2_MIC_GAIN(x) ((x) << 2)
#define EXT2_MIXMODE_DOUBLEDIFF (0)
#define EXT2_MIXMODE_CH1 (1)
#define EXT2_MIXMODE_CH2 (2)
#define EXT2_MIXMODE_MIX (3)
#define EXT4 4
#define EXT4_AGC_ENABLE (1 << 4)
#define EXT4_INPUT_GAIN_MASK (3)
#define EXT4_INPUT_GAIN(x) ((x) & 3)
#define EXT5 5
#define EXT5_INPUT_GAIN(x) ((x) >> 2)
#define EXT6 6
#define EXT6_AGC_CONSTANT_MASK (7 << 2)
#define EXT6_AGC_CONSTANT(x) ((x) << 2)
#define EXT6_AGC_LEVEL_MASK (3)
#define EXT6_AGC_LEVEL(x) (x)

#define AUDIO_NAME "UDA1341"
#define AUDIO_NAME_VERBOSE "UDA1341 audio driver"

#define AUDIO_FMT_MASK (AFMT_S16_LE)
#define AUDIO_FMT_DEFAULT (AFMT_S16_LE)

#define AUDIO_CHANNELS_DEFAULT 2
#define AUDIO_RATE_DEFAULT 44100

#define AUDIO_NBFRAGS_DEFAULT 8
#define AUDIO_FRAGSIZE_DEFAULT 8192

#define S_CLOCK_FREQ 384
#define PCM_ABS(a) (a < 0 ? -a : a)

#define L3C (1<<4)              //GPD4 = L3CLOCK	//add by kyon
#define L3M (1<<3)              //GPD3 = L3MODE
#define L3D (1<<1)              //GPD1 = L3DATA

typedef struct {
int size; /* buffer size */
char *start; /* point to actual buffer */
dma_addr_t dma_addr; /* physical buffer address */
struct semaphore sem; /* down before touching the buffer */
int master; /* owner for buffer allocation, contain size when true */
} audio_buf_t;

typedef struct {
audio_buf_t *buffers; /* pointer to audio buffer structures */
audio_buf_t *buf; /* current buffer used by read/write */
u_int buf_idx; /* index for the pointer above */
u_int fragsize; /* fragment i.e. buffer size */
u_int nbfrags; /* nbr of fragments */
dmach_t dma_ch; /* DMA channel (channel2 for audio) */
u_int dma_ok;
} audio_stream_t;

static audio_stream_t output_stream;
static audio_stream_t input_stream; /* input */

#define NEXT_BUF(_s_,_b_) { \
(_s_)->_b_##_idx++; \
(_s_)->_b_##_idx %= (_s_)->nbfrags; \
(_s_)->_b_ = (_s_)->buffers + (_s_)->_b_##_idx; }


static u_int audio_rate;
static int audio_channels;
static int audio_fmt;
static u_int audio_fragsize;
static u_int audio_nbfrags;


static int audio_rd_refcount;
static int audio_wr_refcount;
#define audio_active (audio_rd_refcount | audio_wr_refcount)

static int audio_dev_dsp;
static int audio_dev_mixer;
static int audio_mix_modcnt;

static int uda1341_volume;
//static u8 uda_sampling;
static int uda1341_boost;
static int mixer_igain=0x4; /* -6db*/

static void uda1341_l3_address(u8 data)
{
	int i;
	unsigned long flags;
	local_irq_save(flags);
	// write_gpio_bit(GPIO_L3MODE, 0);	//s3c2410_gpio_setpin(S3C2410_GPB2,0);
	// write_gpio_bit(GPIO_L3CLOCK, 1);	//s3c2410_gpio_setpin(S3C2410_GPB4,1);
 	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) =
	 	*(volatile unsigned long*)GPIO_PORTD_DATA_V & ~(L3D | L3M | L3C)| L3C; //L3D=L, L3M=L(in address mode), L3C=H
	udelay(1);
	for (i = 0; i < 8; i++) 
	{
		if (data & 0x1) 
		{
 		*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~L3C;            //L3C=L
      	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= L3D;             //L3D=H             
      	udelay(1);    
      	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= L3C;             //L3C=H，L3D=H
      	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= L3D;            
		//s3c2410_gpio_setpin(S3C2410_GPB4,0);		//s3c2410_gpio_setpin(S3C2410_GPB3,1);		//s3c2410_gpio_setpin(S3C2410_GPB4,1);
		} 
		else 
		{
		//s3c2410_gpio_setpin(S3C2410_GPB4,0);		//s3c2410_gpio_setpin(S3C2410_GPB3,0);
		*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~L3C;            //L3C=L,L3D=L
      	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~L3D;
		udelay(1);
		//s3c2410_gpio_setpin(S3C2410_GPB4,1);
		*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= L3C;             //L3C=H
      	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~L3D;            //L3D=L
		}
	data >>= 1;
	}
	//s3c2410_gpio_setpin(S3C2410_GPB2,1);	//s3c2410_gpio_setpin(S3C2410_GPB4,1);
 	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= (L3C | L3M);       //L3M=H,L3C=H  
	local_irq_restore(flags);
}

static void uda1341_l3_data(u8 data)
{
	int i;
	unsigned long flags;
	local_irq_save(flags);
	udelay(1);	
	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= (L3C | L3M);   //L3M=H(in data transfer mode) //add according to ADS
	udelay(1);
	for (i = 0; i < 8; i++) 
	{
		
		if (data & 0x1) 
		{
		//s3c2410_gpio_setpin(S3C2410_GPB4,0);		//s3c2410_gpio_setpin(S3C2410_GPB3,1);
		*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~L3C;              //L3C=L
           	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= L3D;               //L3D=H
		udelay(1);
		//s3c2410_gpio_setpin(S3C2410_GPB4,1);
		*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= (L3C | L3D);       //L3C=H,L3D=H
		} 
		else 
		{
		//s3c2410_gpio_setpin(S3C2410_GPB4,0);		//s3c2410_gpio_setpin(S3C2410_GPB3,0);
		*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~L3C;              //L3C=L
           	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~L3D;              //L3D=L
		udelay(1);
		//s3c2410_gpio_setpin(S3C2410_GPB4,1);
		*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= L3C;               //L3C=H
           	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~L3D;              //L3D=L
		}
		data >>= 1;
	}
	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= (L3C | L3M);    //L3M=H,L3C=H
	local_irq_restore(flags);
}

static void audio_clear_buf(audio_stream_t * s)//未完成 11-09
{
DPRINTK("audio_clear_buf\n");

//if(s->dma_ok) s3c2410_dma_ctrl(s->dma_ch, S3C2410_DMAOP_FLUSH);  //uncertain!

if (s->buffers) {
int frag;

for (frag = 0; frag < s->nbfrags; frag++) {
if (!s->buffers[frag].master)
continue;
dma_free_coherent(NULL,
s->buffers[frag].master,
s->buffers[frag].start,
s->buffers[frag].dma_addr);
}
kfree(s->buffers);
s->buffers = NULL;
}

s->buf_idx = 0;
s->buf = NULL;

}

static int audio_setup_buf(audio_stream_t * s)
{
	int frag;
	int dmasize = 0;
	char *dmabuf = 0;
	dma_addr_t dmaphys = 0;

	if (s->buffers)
	return -EBUSY;

	s->nbfrags = audio_nbfrags;
	s->fragsize = audio_fragsize;

	s->buffers = (audio_buf_t *)
	kmalloc(sizeof(audio_buf_t) * s->nbfrags, GFP_KERNEL);
	if (!s->buffers)
		goto err;
		memset(s->buffers, 0, sizeof(audio_buf_t) * s->nbfrags);

		for (frag = 0; frag < s->nbfrags; frag++) 
		{
			audio_buf_t *b = &s->buffers[frag];

			if (!dmasize) 
			{
				dmasize = (s->nbfrags - frag) * s->fragsize;
				do {
					dmabuf = dma_alloc_coherent(NULL, dmasize, &dmaphys, GFP_KERNEL|GFP_DMA);
					if (!dmabuf)
					dmasize -= s->fragsize;
				} while (!dmabuf && dmasize);
				if (!dmabuf)
				goto err;
				b->master = dmasize;
			}

			b->start = dmabuf;
			b->dma_addr = dmaphys;
			sema_init(&b->sem, 1);
			DPRINTK("buf %d: start %p dma %d\n", frag, b->start, b->dma_addr);

			dmabuf += s->fragsize;
			dmaphys += s->fragsize;
			dmasize -= s->fragsize;
		}

	s->buf_idx = 0;
	s->buf = &s->buffers[0];
	return 0;

	err:
	printk(AUDIO_NAME ": unable to allocate audio memory\n ");
	audio_clear_buf(s);
	return -ENOMEM;
}

//static void audio_dmaout_done_callback(s3c2410_dma_chan_t *ch, void *buf, int size,s3c2410_dma_buffresult_t result) //modified by kyon
static void audio_dmaout_done_callback(void *buf, int size)
{
	audio_buf_t *b = (audio_buf_t *) buf;
	up(&b->sem);
	wake_up(&b->sem.wait);
}

//static void audio_dmain_done_callback(s3c2410_dma_chan_t *ch, void *buf, int size,s3c2410_dma_buffresult_t result)
static void audio_dmain_done_callback(void *buf, int size)
{
		audio_buf_t *b = (audio_buf_t *) buf;
	b->size = size;
	up(&b->sem);
	wake_up(&b->sem.wait);
}
/* using when write */
static int audio_sync(struct file *file)
{
	audio_stream_t *s = &output_stream;
	audio_buf_t *b = s->buf;

	DPRINTK("audio_sync\n");

	if (!s->buffers)
		return 0;

	if (b->size != 0) 
	{
		down(&b->sem);
		//s3c2410_dma_enqueue(s->dma_ch, (void *) b, b->dma_addr, b->size); //need modify by kyon
		b->size = 0;
		NEXT_BUF(s, buf);
	}

	b = s->buffers + ((s->nbfrags + s->buf_idx - 1) % s->nbfrags);
	if (down_interruptible(&b->sem))
		return -EINTR;
	up(&b->sem);

	return 0;
}

static inline int copy_from_user_mono_stereo(char *to, const char *from, int count)
{
	u_int *dst = (u_int *)to;
	const char *end = from + count;

	if (access_ok(VERIFY_READ, from, count))
		return -EFAULT;

	if ((int)from & 0x2) 
	{
		u_int v;
		__get_user(v, (const u_short *)from); from += 2;
		*dst++ = v | (v << 16);
	}

	while (from < end-2) 
	{
		u_int v, x, y;
		__get_user(v, (const u_int *)from); from += 4;
		x = v << 16;
		x |= x >> 16;
		y = v >> 16;
		y |= y << 16;
		*dst++ = x;
		*dst++ = y;
	}
	
	if (from < end) 
	{
		u_int v;
		__get_user(v, (const u_short *)from);
		*dst = v | (v << 16);
	}

	return 0;
}

static ssize_t sep4020_audio_write(struct file *file, const char *buffer,size_t count, loff_t * ppos)
{
	const char *buffer0 = buffer;
	audio_stream_t *s = &output_stream;
	int chunksize, ret = 0;

	DPRINTK("audio_write : start count=%d\n", count);

	switch (file->f_flags & O_ACCMODE) {
		case O_WRONLY:
		case O_RDWR:
		break;
		default:
			return -EPERM;
	}

	if (!s->buffers && audio_setup_buf(s))
		return -ENOMEM;

	count &= ~0x03;

	while (count > 0) {
		audio_buf_t *b = s->buf;

		if (file->f_flags & O_NONBLOCK) {
			ret = -EAGAIN;
			if (down_trylock(&b->sem))
				break;
		} else {
			ret = -ERESTARTSYS;
			if (down_interruptible(&b->sem))
			break;
		}

		if (audio_channels == 2) {
			chunksize = s->fragsize - b->size;
			if (chunksize > count)
			chunksize = count;
			DPRINTK("write %d to %d\n", chunksize, s->buf_idx);
			if (copy_from_user(b->start + b->size, buffer, chunksize)) {
				up(&b->sem);
				return -EFAULT;
			}
			b->size += chunksize;
		} else {
			chunksize = (s->fragsize - b->size) >> 1;

			if (chunksize > count)
			chunksize = count;
			DPRINTK("write %d to %d\n", chunksize*2, s->buf_idx);
			if (copy_from_user_mono_stereo(b->start + b->size,buffer, chunksize)) {
			up(&b->sem);
			return -EFAULT;
			}
			b->size += chunksize*2;
		}

		buffer += chunksize;
		count -= chunksize;
		if (b->size < s->fragsize) {
		up(&b->sem);
		break;
		}
		//if((ret = s3c2410_dma_enqueue(s->dma_ch, (void *) b, b->dma_addr, b->size))) {
			//printk(PFX"dma enqueue failed.\n");
			//return ret;
		//}															//need modify
		b->size = 0;
		NEXT_BUF(s, buf);
	}
	if ((buffer - buffer0))
	ret = buffer - buffer0;
	DPRINTK("audio_write : end count=%d\n\n", ret);
	return ret;
}


static ssize_t sep4020_audio_read(struct file *file, char *buffer,size_t count, loff_t * ppos)
{
	const char *buffer0 = buffer;
	audio_stream_t *s = &input_stream;
	int chunksize, ret = 0;
	DPRINTK("audio_read: count=%d\n", count);
/*
	if (ppos != &file->f_pos)
	return -ESPIPE;
*/
	if (!s->buffers) {
		int i;
		if (audio_setup_buf(s))
			return -ENOMEM;

		for (i = 0; i < s->nbfrags; i++) {
			audio_buf_t *b = s->buf;
			down(&b->sem);
			//s3c2410_dma_enqueue(s->dma_ch, (void *) b, b->dma_addr, s->fragsize);//need modify
			NEXT_BUF(s, buf);
		}
	}
	while (count > 0) {
		audio_buf_t *b = s->buf;
	/* Wait for a buffer to become full */
		if (file->f_flags & O_NONBLOCK) {
			ret = -EAGAIN;
			if (down_trylock(&b->sem))
				break;
		} else {
				ret = -ERESTARTSYS;
				if (down_interruptible(&b->sem))
				break;
		}
		chunksize = b->size;
		if (chunksize > count)
			chunksize = count;
		DPRINTK("read %d from %d\n", chunksize, s->buf_idx);
		if (copy_to_user(buffer, b->start + s->fragsize - b->size,chunksize)) {
			up(&b->sem);
			return -EFAULT;
		}

		b->size -= chunksize;

		buffer += chunksize;
		count -= chunksize;
		if (b->size > 0) {
			up(&b->sem);
			break;
		}

		/* Make current buffer available for DMA again */
		//s3c2410_dma_enqueue(s->dma_ch, (void *) b, b->dma_addr, s->fragsize); //need monidfy

		NEXT_BUF(s, buf);
	}

	if ((buffer - buffer0))
	ret = buffer - buffer0;

	// DPRINTK("audio_read: return=%d\n", ret);
	return ret;
}


static unsigned int sep4020_audio_poll(struct file *file, struct poll_table_struct *wait)
{
	unsigned int mask = 0;
	int i;

	DPRINTK("audio_poll(): mode=%s\n", (file->f_mode & FMODE_WRITE) ? "w" : "");

	if (file->f_mode & FMODE_READ) 
	{
		if (!input_stream.buffers && audio_setup_buf(&input_stream))
		return -ENOMEM;
		poll_wait(file, &input_stream.buf->sem.wait, wait);

		for (i = 0; i < input_stream.nbfrags; i++) 
		{
			if (atomic_read(&input_stream.buffers[i].sem.count) > 0)
			mask |= POLLIN | POLLWRNORM;
			break;
		}
	}

	if (file->f_mode & FMODE_WRITE) 
	{
		if (!output_stream.buffers && audio_setup_buf(&output_stream))
		return -ENOMEM;
		poll_wait(file, &output_stream.buf->sem.wait, wait);

		for (i = 0; i < output_stream.nbfrags; i++) 
		{
			if (atomic_read(&output_stream.buffers[i].sem.count) > 0)
			mask |= POLLOUT | POLLWRNORM;
			break;
		}
	}

	DPRINTK("audio_poll() returned mask of %s\n", (mask & POLLOUT) ? "w" : "");
	return mask;
}


static loff_t sep4020_audio_llseek(struct file *file, loff_t offset, int origin)
{
	return -ESPIPE;
}


static int sep4020_mixer_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	int ret;
	long val = 0;

	switch (cmd) 
	{
	case SOUND_MIXER_INFO:
		{
			mixer_info info;
			strncpy(info.id, "UDA1341", sizeof(info.id));
			strncpy(info.name,"Philips UDA1341", sizeof(info.name));
			info.modify_counter = audio_mix_modcnt;
			return copy_to_user((void *)arg, &info, sizeof(info));
		}

	case SOUND_OLD_MIXER_INFO:
		{
		_old_mixer_info info;
		strncpy(info.id, "UDA1341", sizeof(info.id));
		strncpy(info.name,"Philips UDA1341", sizeof(info.name));
		return copy_to_user((void *)arg, &info, sizeof(info));
		}

	case SOUND_MIXER_READ_STEREODEVS:
		return put_user(0, (long *) arg);

	case SOUND_MIXER_READ_CAPS:
		val = SOUND_CAP_EXCL_INPUT;
		return put_user(val, (long *) arg);

	case SOUND_MIXER_WRITE_VOLUME:
		ret = get_user(val, (long *) arg);
		if (ret)
		return ret;
		uda1341_volume = 63 - (((val & 0xff) + 1) * 63) / 100;
		uda1341_l3_address(UDA1341_REG_DATA0);
		uda1341_l3_data(uda1341_volume);
		break;

	case SOUND_MIXER_READ_VOLUME:
		val = ((63 - uda1341_volume) * 100) / 63;
		val |= val << 8;
		return put_user(val, (long *) arg);

	case SOUND_MIXER_READ_IGAIN:
		val = ((31- mixer_igain) * 100) / 31;
		return put_user(val, (int *) arg);

	case SOUND_MIXER_WRITE_IGAIN:
		ret = get_user(val, (int *) arg);
		if (ret)
		return ret;
		mixer_igain = 31 - (val * 31 / 100);
		/* use mixer gain channel 1*/
		uda1341_l3_address(UDA1341_REG_DATA0);
		uda1341_l3_data(EXTADDR(EXT0));
		uda1341_l3_data(EXTDATA(EXT0_CH1_GAIN(mixer_igain)));
		break;

	default:
		DPRINTK("mixer ioctl %u unknown\n", cmd);
		return -ENOSYS;
	}

	audio_mix_modcnt++;
	return 0;
}
/*killed 11-09
static long audio_set_dsp_speed(long val)
{
	#ifdef DEBUG
 	printk("audio_set_dsp_speed\n");
	#endif	
	unsigned int prescaler;
	//prescaler=(IISPSR_A(iispsr_value(S_CLOCK_FREQ, val))| IISPSR_B(iispsr_value(S_CLOCK_FREQ, val))); //11-09
	//writel(prescaler, iis_base + S3C2410_IISPSR); //need modify by kyon 11-08
	printk(PFX "audio_set_dsp_speed:%ld prescaler:%i\n",val,prescaler);
	return (audio_rate = val);
}*/

static int sep4020_audio_ioctl(struct inode *inode, struct file *file, uint cmd, ulong arg)
{
	#ifdef DEBUG
 	printk("sep4020_audio_ioctl\n");
	#endif	
	long val;

	switch (cmd) 
	{
	case SNDCTL_DSP_SETFMT:
		get_user(val, (long *) arg);
		if (val & AUDIO_FMT_MASK) 
		{
			audio_fmt = val;
			break;
		} 
		else
		return -EINVAL;

	case SNDCTL_DSP_CHANNELS:
	case SNDCTL_DSP_STEREO:
		get_user(val, (long *) arg);
		if (cmd == SNDCTL_DSP_STEREO)
			val = val ? 2 : 1;
		if (val != 1 && val != 2)
			return -EINVAL;
		audio_channels = val;
		break;

	case SOUND_PCM_READ_CHANNELS:
		put_user(audio_channels, (long *) arg);
		break;

	case SNDCTL_DSP_SPEED:
		get_user(val, (long *) arg);
		//val = audio_set_dsp_speed(val);moidfied 11-09
		val = 44100;
		if (val < 0)
			return -EINVAL;
		put_user(val, (long *) arg);
		break;

	case SOUND_PCM_READ_RATE:
		put_user(audio_rate, (long *) arg);
	break;

	case SNDCTL_DSP_GETFMTS:
		put_user(AUDIO_FMT_MASK, (long *) arg);
	break;

	case SNDCTL_DSP_GETBLKSIZE:
		if(file->f_mode & FMODE_WRITE)
			return put_user(audio_fragsize, (long *) arg);
		else
			return put_user(audio_fragsize, (int *) arg);

	case SNDCTL_DSP_SETFRAGMENT:
		if (file->f_mode & FMODE_WRITE) 
		{
			if (output_stream.buffers)
				return -EBUSY;
			get_user(val, (long *) arg);
			audio_fragsize = 1 << (val & 0xFFFF);
			if (audio_fragsize < 16)
				audio_fragsize = 16;
			if (audio_fragsize > 16384)
				audio_fragsize = 16384;
			audio_nbfrags = (val >> 16) & 0x7FFF;
			if (audio_nbfrags < 2)
				audio_nbfrags = 2;
			if (audio_nbfrags * audio_fragsize > 128 * 1024)
				audio_nbfrags = 128 * 1024 / audio_fragsize;
			if (audio_setup_buf(&output_stream))
				return -ENOMEM;
		}
		if (file->f_mode & FMODE_READ) 
		{
			if (input_stream.buffers)
				return -EBUSY;
			get_user(val, (int *) arg);
			audio_fragsize = 1 << (val & 0xFFFF);
			if (audio_fragsize < 16)
				audio_fragsize = 16;
			if (audio_fragsize > 16384)
				audio_fragsize = 16384;
			audio_nbfrags = (val >> 16) & 0x7FFF;
			if (audio_nbfrags < 2)
				audio_nbfrags = 2;
			if (audio_nbfrags * audio_fragsize > 128 * 1024)
				audio_nbfrags = 128 * 1024 / audio_fragsize;
			if (audio_setup_buf(&input_stream))
				return -ENOMEM;
		}
	break;

	case SNDCTL_DSP_SYNC:
		return audio_sync(file);

	case SNDCTL_DSP_GETOSPACE:
		{
		audio_stream_t *s = &output_stream;
		audio_buf_info *inf = (audio_buf_info *) arg;
		int err = access_ok(VERIFY_WRITE, inf, sizeof(*inf));
		int i;
		int frags = 0, bytes = 0;

		if (err)
			return err;
		for (i = 0; i < s->nbfrags; i++) 
		{
			if (atomic_read(&s->buffers[i].sem.count) > 0) 
			{
				if (s->buffers[i].size == 0) frags++;
				bytes += s->fragsize - s->buffers[i].size;
			}
		}
		put_user(frags, &inf->fragments);
		put_user(s->nbfrags, &inf->fragstotal);
		put_user(s->fragsize, &inf->fragsize);
		put_user(bytes, &inf->bytes);
		break;
		}

	case SNDCTL_DSP_GETISPACE:
		{
		audio_stream_t *s = &input_stream;
		audio_buf_info *inf = (audio_buf_info *) arg;
		int err = access_ok(VERIFY_WRITE, inf, sizeof(*inf));
		int i;
		int frags = 0, bytes = 0;

		if (!(file->f_mode & FMODE_READ))
			return -EINVAL;

		if (err)
			return err;
		for(i = 0; i < s->nbfrags; i++)
		{
			if (atomic_read(&s->buffers[i].sem.count) > 0)
			{
				if (s->buffers[i].size == s->fragsize)
					frags++;
				bytes += s->buffers[i].size;
			}
		}
		put_user(frags, &inf->fragments);
		put_user(s->nbfrags, &inf->fragstotal);
		put_user(s->fragsize, &inf->fragsize);
		put_user(bytes, &inf->bytes);
		break;
	}

	case SNDCTL_DSP_RESET:
		if (file->f_mode & FMODE_READ) 
		{
			audio_clear_buf(&input_stream);
		}
		if (file->f_mode & FMODE_WRITE) 
		{
			audio_clear_buf(&output_stream);
		}
	return 0;
	case SNDCTL_DSP_NONBLOCK:
		file->f_flags |= O_NONBLOCK;
		return 0;
	case SNDCTL_DSP_POST:
	case SNDCTL_DSP_SUBDIVIDE:
	case SNDCTL_DSP_GETCAPS:
	case SNDCTL_DSP_GETTRIGGER:
	case SNDCTL_DSP_SETTRIGGER:
	case SNDCTL_DSP_GETIPTR:
	case SNDCTL_DSP_GETOPTR:
	case SNDCTL_DSP_MAPINBUF:
	case SNDCTL_DSP_MAPOUTBUF:
	case SNDCTL_DSP_SETSYNCRO:
	case SNDCTL_DSP_SETDUPLEX:
		return -ENOSYS;
	default:
		return sep4020_mixer_ioctl(inode, file, cmd, arg);
	}

	return 0;
}

static int sep4020_audio_open(struct inode *inode, struct file *file)
{
	#ifdef DEBUG
 	printk("sep4020_audio_open\n");
	#endif
	int cold = !audio_active;

	DPRINTK("audio_open\n");
	if ((file->f_flags & O_ACCMODE) == O_RDONLY) 
	{
		if (audio_rd_refcount || audio_wr_refcount)
		return -EBUSY;
	audio_rd_refcount++;
	} 
	else if ((file->f_flags & O_ACCMODE) == O_WRONLY) 
	{
		if (audio_wr_refcount)
		return -EBUSY;
		audio_wr_refcount++;
	}
	else if ((file->f_flags & O_ACCMODE) == O_RDWR) 
	{
		if (audio_rd_refcount || audio_wr_refcount)
			return -EBUSY;
		audio_rd_refcount++;
		audio_wr_refcount++;
	} 
	else
		return -EINVAL;

	if (cold) 
	{
		audio_rate = AUDIO_RATE_DEFAULT;
		audio_channels = AUDIO_CHANNELS_DEFAULT;
		audio_fragsize = AUDIO_FRAGSIZE_DEFAULT;
		audio_nbfrags = AUDIO_NBFRAGS_DEFAULT;
		if ((file->f_mode & FMODE_WRITE))
		{
			init_sep4020_iis_bus_tx();	//这里调用iis的tx初始化函数
			audio_clear_buf(&output_stream);
		}
		//add//////////////////////////////////////
		//if (!output_stream.buffers && audio_setup_buf(&output_stream))    
		//return  -ENOMEM;
		////////////////////////////////////////////// ///
		if ((file->f_mode & FMODE_READ))
		{
			init_sep4020_iis_bus_rx();	//rx初始化函数没写
			audio_clear_buf(&input_stream);
		}
	}
	return 0;
}


static int sep4020_mixer_open(struct inode *inode, struct file *file)
{
	return 0;
}


static int sep4020_audio_release(struct inode *inode, struct file *file)
{
	#ifdef DEBUG
 	printk("sep4020_audio_release\n");
	#endif
	DPRINTK("audio_release\n");

	if (file->f_mode & FMODE_READ) 
	{
		if (audio_rd_refcount == 1)
			audio_clear_buf(&input_stream);
		audio_rd_refcount = 0;
	}
	if(file->f_mode & FMODE_WRITE) 
	{
		if (audio_wr_refcount == 1) 
		{
			audio_sync(file);
			audio_clear_buf(&output_stream);
			audio_wr_refcount = 0;
		}
	}
	return 0;
}

static int sep4020_mixer_release(struct inode *inode, struct file *file)
{
	return 0;
}


static struct file_operations sep4020_audio_fops = {
llseek: sep4020_audio_llseek,
write: sep4020_audio_write,
read: sep4020_audio_read,
poll: sep4020_audio_poll,
ioctl: sep4020_audio_ioctl,
open: sep4020_audio_open,
release: sep4020_audio_release
};

static struct file_operations sep4020_mixer_fops = {
ioctl: sep4020_mixer_ioctl,
open: sep4020_mixer_open,
release: sep4020_mixer_release
};

static void init_uda1341(void)
{	
	#ifdef DEBUG
 	printk("init_uda1341\n");
	#endif
	unsigned long flags;
      uda1341_volume = 62 - ((DEF_VOLUME * 61) / 100);
      uda1341_boost = 0;
	//uda_sampling = DATA2_DEEMP_NONE;
	//uda_sampling &= ~(DATA2_MUTE);
      local_irq_save(flags);
	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) &= ~(L3M|L3C|L3D);
	*(volatile unsigned long*)(GPIO_PORTD_DATA_V) |= (L3M|L3C); //Start condition : L3M=H, L3C=H
       local_irq_restore(flags);
	//以下配置可能需要修改 marked at 11-08
        uda1341_l3_address(UDA1341_REG_STATUS);
        uda1341_l3_data(0x40 | STAT0_SC_256FS | STAT0_IF_MSB|STAT0_DC_FILTER); // reset uda1341 修改为256fs 11-08
        uda1341_l3_data(STAT1 | STAT1_ADC_ON | STAT1_DAC_ON);

        uda1341_l3_address(UDA1341_REG_DATA0);
        uda1341_l3_data(DATA0 |DATA0_VOLUME(0x0)); // maximum volume
        uda1341_l3_data(DATA1 |DATA1_BASS(uda1341_boost)| DATA1_TREBLE(0));
        uda1341_l3_data((DATA2 |DATA2_DEEMP_NONE) &~(DATA2_MUTE));
        uda1341_l3_data(EXTADDR(EXT2));
        uda1341_l3_data(EXTDATA(EXT2_MIC_GAIN(0x6)) | EXT2_MIXMODE_CH1);//input channel 1 select(input channel 2 off)
}

static void init_sep4020_iis_bus(void)
{
	#ifdef DEBUG
 	printk("init_sep4020_iis_bus useless\n");
	#endif       
}

static void init_sep4020_iis_bus_rx(void) {/*目前不需要完成这个函数*/}

static void init_sep4020_iis_bus_tx(void)
{
	#ifdef DEBUG
 	printk("init_sep4020_iis_bus_tx\n");
	#endif
	char *dstr="TX"; 	
	//write_reg(I2S_T_CR, MUTE(0) + RESET_1(0) + ALIGN(0) + WS(0) + WID(1) 16bit+ DIR(0)+ MODE(0) + MONO(0) + STOP(1) + DIV(0X1f)); 1F对应88MHz的44.1k
	*(volatile unsigned long*)(I2S_CTRL_V) = MUTE(0) + RESET_1(0) + ALIGN(0) + WS(0) + WID(1) + DIR(0)+ MODE(0) + MONO(0) + STOP(1) + DIV(0X1f);	
	//write_reg(I2S_T_IR, 0x04); 
	*(volatile unsigned long*)(I2S_INT_V) = 0x04;	//发送中断始能	
	udelay(10);
 	*(volatile unsigned long*)(I2S_CTRL_V) &= 0Xfffeffff; //发送

	//audio_set_dsp_speed(audio_rate); killed 11-09

}

static int __init audio_init_dma(audio_stream_t * s, char *desc)
{
	#ifdef DEBUG
 	printk("audio_init_dma\n");
	#endif	
	int ret;
	enable_irq(INTSRC_DMAC);
 	*(volatile unsigned long*)(INTC_IMR_V) &= ~(1 << INTSRC_DMAC);
	//清除要用的dma通道（dma1）上的传输完成中断寄存器
	*(volatile unsigned long*)(DMAC_INTTCCLEAR_V) = 0X02; 
	*(volatile unsigned long*)(DMAC_INTTCCLEAR_V) = 0X00;
  	//清除要用的dma通道（dma1）上的错误中断寄存器
	*(volatile unsigned long*)(DMAC_INTINTERRCLR_V) = 0x02;
  	*(volatile unsigned long*)(DMAC_INTINTERRCLR_V) = 0x00;
 	//添加dma中断队列
	//ret = request_irq(INTSRC_DMAC, sep4020_dma_irqhandler, SA_INTERRUPT,  "sep4020 dma", NULL);
	ret = request_irq(INTSRC_DMAC, audio_dmain_done_callback, SA_INTERRUPT,  "sep4020 dma", NULL);	
	if (ret)
	{
		printk(KERN_ERR "IRQ%d already in use\n", INTSRC_RTC);
		goto tick_err;
	}
	else return ret;

 tick_err:
	free_irq(INTSRC_RTC, NULL);
	return ret;
/*
        int ret ;
        //s3c2410_dmasrc_t source;  //modified by kyon
        int hwcfg;
        unsigned long devaddr;
        dmach_t channel;
        int dcon;
        unsigned int flags = 0;

        if(s->dma_ch == DMA_CH2){
               channel = 2;
               source = S3C2410_DMASRC_MEM;
               hwcfg = 3;
               devaddr = 0x55000010;
               dcon = 0xa0800000;
               flags = S3C2410_DMAF_AUTOSTART;

               s3c2410_dma_devconfig(channel, source, hwcfg, devaddr);
               s3c2410_dma_config(channel, 2, dcon);
               s3c2410_dma_set_buffdone_fn(channel, audio_dmaout_done_callback);
               s3c2410_dma_setflags(channel, flags);
               ret = s3c2410_dma_request(s->dma_ch, &s3c2410iis_dma_out, NULL);
               s->dma_ok = 1;
               return ret;
        }
        else if(s->dma_ch == DMA_CH1){
               channel =1;
               source =S3C2410_DMASRC_HW;
               hwcfg =3;
               devaddr = 0x55000010;
               dcon = 0xa2900000;
               flags = S3C2410_DMAF_AUTOSTART;

               s3c2410_dma_devconfig(channel, source, hwcfg, devaddr);
               s3c2410_dma_config(channel, 2, dcon);
               s3c2410_dma_set_buffdone_fn(channel, audio_dmain_done_callback);
               s3c2410_dma_setflags(channel, flags);
               ret = s3c2410_dma_request(s->dma_ch, &s3c2410iis_dma_in, NULL);
               s->dma_ok =1;
               return ret ;
        }
else
return 1;*/
return 0; //add 11-08
}

//static int audio_clear_dma(audio_stream_t * s,sep4020_dma_client_t *client)
static int audio_clear_dma(audio_stream_t * s)							 //modified by kyon
{
        //s3c2410_dma_set_buffdone_fn(s->dma_ch, NULL);
        //s3c2410_dma_free(s->dma_ch, client);
	return 0;
}

static int __init sep4020iis_probe(struct device *dev) 
{
	return 0;
}


static int sep4020iis_remove(struct device *dev) {
	#ifdef DEBUG
 	printk("sep4020iis_remove\n");
	#endif
        unregister_sound_dsp(audio_dev_dsp);
        unregister_sound_mixer(audio_dev_mixer);
        //audio_clear_dma(&output_stream,&s3c2410iis_dma_out); 		//need modify
        //audio_clear_dma(&input_stream,&s3c2410iis_dma_in); /* input */
        printk(AUDIO_NAME_VERBOSE " unloaded\n");
        return 0;
}

static struct device_driver sep4020iis_driver = {
        .name = "sep4020-iis",
        .bus = &platform_bus_type,		
        .probe = sep4020iis_probe,
        .remove = sep4020iis_remove,
};

static int __init sep4020_uda1341_init(void) 
{
	#ifdef DEBUG
 	printk("sep4020_uda1341_init\n");
	#endif
      memzero(&input_stream, sizeof(audio_stream_t));
      memzero(&output_stream, sizeof(audio_stream_t));
      //struct platform_device *pdev = to_platform_device(dev); //modified by kyon
	//struct resource *res;
      unsigned long flags;
	/*res = platform_get_resource(pdev, IORESOURCE_MEM, 0);
        if (res == NULL) {
                printk(KERN_INFO PFX "failed to get memory region resouce\n");
                return -ENOENT;
           }

        iis_base = (void *)S3C24XX_VA_IIS ; //need modify
        if (iis_base == 0) {
                printk(KERN_INFO PFX "failed to ioremap() region\n");
                return -EINVAL;
        }
      iis_clock = clk_get(dev, "iis");
        if (iis_clock == NULL) {
                printk(KERN_INFO PFX "failed to find clock source\n");
                return -ENOENT;
        }*/
      local_irq_save(flags);
	//初始化L3总线GPIO口
	*(volatile unsigned long*)(GPIO_PORTD_DIR_V) &= ~(0xd<<1);       //GPB[4:1]=00_0 Output(L3CLOCK):Output(L3DATA):Output(L3MODE)   
	*(volatile unsigned long*)(GPIO_PORTD_SEL_V) |= (0xd<<1);        //GPD[4:1] 1 1010 
	
	//GPIO_PG11控制将处理器的数据信号I2S_SD连接在I2S_DIN或者I2S_DOUT上。放音过程种将GPIO_PG11置高，I2S_SD与I2S_DIN相连。init_datapath()是使GPIO_PORTG的第11位输出位高.
	//init_datapath() in ADS
	*(volatile unsigned long*)(GPIO_PORTG_DIR_V) &= ~(0x1<<11);
	*(volatile unsigned long*)(GPIO_PORTG_SEL_V) |= 0x1<<11;
	*(volatile unsigned long*)(GPIO_PORTG_DATA_V) |= 0x1<<11;
	//init_PWM() in ADS  给UDA1341提供CDCLK
	*(volatile unsigned long*)PWM4_CTRL_V =0x00;
      *(volatile unsigned long*)PWM4_DIV_V =0x4; 	//88MHz/(4*2)=11Mhz 11M/256fs=42.96k
  	*(volatile unsigned long*)PWM4_PERIOD_V =0x2;	//计数时钟为总线的DIV分频
  	*(volatile unsigned long*)PWM4_DATA_V =0x1;  	//周期为两个计数时钟
  	*(volatile unsigned long*)PWM_ENABLE_V =0x1<<3;	//高电平为一个计数时钟

        local_irq_restore(flags);
        init_sep4020_iis_bus();
        init_uda1341();

      output_stream.dma_ch = DMA_CH2;
	audio_init_dma(&output_stream, "UDA1341 out");
	/*暂时注释掉
        if (audio_init_dma(&output_stream, "UDA1341 out")) {
                //audio_clear_dma(&output_stream,&sep4020iis_dma_out); //need modify
                printk( KERN_WARNING AUDIO_NAME_VERBOSE
                ": unable to get DMA channels\n" );
                return -EBUSY; 
       		}
        input_stream.dma_ch = DMA_CH1;	
        if (audio_init_dma(&input_stream, "UDA1341 in")) {
                //audio_clear_dma(&input_stream,&sep4020iis_dma_in);	//need modify
                printk( KERN_WARNING AUDIO_NAME_VERBOSE
                ": unable to get DMA channels\n" );
                return -EBUSY;
       		}
	*/		
        audio_dev_dsp = register_sound_dsp(&sep4020_audio_fops, -1);
        audio_dev_mixer = register_sound_mixer(&sep4020_mixer_fops, -1);
        printk(AUDIO_NAME_VERBOSE " initialized\n");
	  return 0;	        //return driver_register(&sep4020iis_driver);
}

static void __exit sep4020_uda1341_exit(void) 
{
        driver_unregister(&sep4020iis_driver);
}

module_init(sep4020_uda1341_init);
module_exit(sep4020_uda1341_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("aokikyon@gmail.com");
MODULE_DESCRIPTION("sep4020 uda1341 sound driver");

